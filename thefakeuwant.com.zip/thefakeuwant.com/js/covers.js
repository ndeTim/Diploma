// Получаем все кнопки с классом "openPop"
var openPopBtns = document.querySelectorAll('.containerForCover');

// Добавляем обработчик события для каждой кнопки
openPopBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    // Получаем путь к изображению из атрибута "data-img" кнопки
    var imgSrc = btn.getAttribute('data-img');
    // Устанавливаем путь к изображению в src тега img в pop-up окне
    document.getElementById('popupImg').src = imgSrc;
    // Показываем pop-up окно
    document.getElementById('popup').style.display = 'block';
    document.getElementById('mobileMenuIcon').style.display = 'none';
  });
});

// Добавляем обработчик события для кнопки закрытия
document.querySelector('.closeBtn').addEventListener('click', function() {
  // Скрываем pop-up окно
  document.getElementById('popup').style.display = 'none';
  document.getElementById('mobileMenuIcon').style.display = 'block';
});



