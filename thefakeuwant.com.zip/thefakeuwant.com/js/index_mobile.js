function toggleMobileMenu() {
    var mobileMenu = document.getElementById('mobileMenu');
    var mobileMenuIcon = document.getElementById('mobileMenuIcon');
    
    if (mobileMenu.style.display === 'block') {
        mobileMenu.style.display = 'none';
        mobileMenuIcon.classList.remove('menu-closed');
        mobileMenuIcon.classList.add('menu-open');
    } else {
        mobileMenu.style.display = 'block';
        mobileMenuIcon.classList.remove('menu-open');
        mobileMenuIcon.classList.add('menu-closed');
    }
}
