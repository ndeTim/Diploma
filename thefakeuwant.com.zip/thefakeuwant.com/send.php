<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require 'vendor/autoload.php'; // Подключение SparkPost PHP библиотеки

use SparkPost\SparkPost;
use Http\Adapter\Guzzle7\Client as GuzzleAdapter;
use GuzzleHttp\Client;

// Получаем данные отправителя из формы
$from_email = $_POST['from_email'] ?? null;
$from_name = $_POST['from_name'] ?? null;

// Получаем данные получателя
$to_email = "thefakeuwant@gmail.com";
$to_name = "thefakeuwant";

// Получаем текст сообщения из формы
$message_text = $_POST['message_text'] ?? null;

// Проверяем наличие всех данных
if ($from_email && $from_name && $message_text) {
    // Инициализация объекта SparkPost с использованием Guzzle6 адаптера
    $httpClient = new GuzzleAdapter(new Client());
    $sparkpost = new SparkPost($httpClient, ['key' => '7e5afa7121c0f226737e5cce785e55416a39ec5c']); // Замените 'YOUR_API_KEY' на ваш API ключ SparkPost

    // Создание и отправка сообщения
    try {
        $response = $sparkpost->transmissions->post([
            'content' => [
                'from' => [
                    'name' => $from_name,
                    'email' => $from_email,
                ],
                'subject' => 'Subject of the Email',
                'text' => $message_text,
            ],
            'recipients' => [
                [
                    'address' => [
                        // 'name' => $to_name,
                        'email' => $to_email,
                    ],
                ],
            ],
        ]);
        // Вывод сообщения об успешной отправке письма и скрытие формы
    } catch (\Exception $e) {
        // Вывод сообщения об ошибке
        echo "Failed to send email: " . $e->getMessage();
    }

} else {
    // Вывод сообщения о незаполненных полях формы
    echo "Please fill out all fields in the form.";
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/about.css">
    <link rel="stylesheet" href="/css/style.css">
    <title>thefakeuwant</title>
</head>
<body>
    <div class="back" id="sky"></div>
    <script src="/js/index.js"></script>
    <div class="elements">
        <div class="header">
            <div class="forLogo">
                <img src="/img/Logo.png" class="logo">
                <a href="/" class="name">thefakeuwant</a>
            </div>
            <div class="navigation">
                <a href="/pages/beats.html" class="nav navbeats">Биты</a>
                <a href="/pages/covers.html" class="nav navcovers">Обложки</a>
                <a href="/pages/about.html" class="nav navabout">О нас</a>
            </div>
        </div>
        <div class="line"></div>
        <div class="container">
            <div class="textBold"><span class="textBlueBold">Мы, </span> команда битмейкеров и дизайнеров, занимаемся увеличением качественных продуктов на российском рынке.</div>
            <div class="container2" id="contact-form">
                <form action="/send.php" method="post" class="form">
                    <input type="email" name="from_email" class="input1" placeholder="Ваш e-mail" required>
                    <input type="text" name="from_name" class="input1" placeholder="ФИО" required>
                    <textarea name="message_text" class="input2" placeholder="Сообщение" required></textarea>
                    <input type="submit" value="Отправить" class="send">
                    <div id="success-message">
                    <p class="success-message">Письмо отправлено!</p>
                </div>
                </form>
                <div class="forDetails">
                    <details>
                        <summary>Будут ли теги удалены?</summary>
                        <p>Да, теги удаляются после приобретения.</p>
                    </details>
                    <details>
                        <summary>Как скоро я получу бит?</summary>
                        <p>Если вы покупаете с помощью нашего встроенного плеера на сайте, то вы получаете бит сразу после покупки. Если вы обращаетесь за покупкой к нам в социальные сети, то получите бит в течение 2 дней.</p>
                    </details>
                    <details>
                        <summary>Какие есть форматы битов?</summary>
                        <p>Форматы битов представлены на главной странице и при добавлении битов в корзину.</p>
                    </details>
                </div>
            </div>
        </div>
        <div class="line lineMargin"></div>
        <div class="ender">
            <div class="rights">thefakeuwant.com, 2023 © All rights reserved.</div>
            <div class="links">
                <a href="https://vk.com/thefakeuwant" class="vk"></a>
                <a href="https://t.me/thefakeuwantspace" class="tg"></a>
            </div>
        </div>
    </div>
</body>
</html>
